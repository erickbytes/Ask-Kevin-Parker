# -*- coding: utf-8 -*-

db.define_table('questions',
                Field('asked', requires=IS_NOT_EMPTY()),
                Field('answer',requires=IS_NOT_EMPTY()))

db.define_table('discography',
                Field('song_name',requires=IS_NOT_EMPTY()),
                Field('lyrics', 'text', requires=IS_NOT_EMPTY()),
                Field('album',requires=IS_NOT_EMPTY()))

db.define_table('safety',
                Field('answer',requires=IS_NOT_EMPTY()))
